#include <stdio.h>
#include <stdlib.h>

int main() {
    int n = 10;
    int gray[n][n];
    int rgb[n][n][3];


    printf("\n");
    printf("RGB Image:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            rgb[i][j][0] = rand() % 256; 
            rgb[i][j][1] = rand() % 256; 
            rgb[i][j][2] = rand() % 256; 
            printf("(%d, %d, %d) ", rgb[i][j][0], rgb[i][j][1], rgb[i][j][2]);
        }
        printf("\n");
    }

    printf("\nGrayscale Image:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            gray[i][j] = (int)(0.299 * rgb[i][j][0] + 0.587 * rgb[i][j][1] + 0.114 * rgb[i][j][2]);
            printf("%d ", gray[i][j]);
        }
        printf("\n");
    }

    return 0;
}

