#include <stdio.h>
#include <unistd.h> //kust like delay() in Arduino IDE

int main() {

   
       	
	int min = 0; 
	int sec = 0;
	int user = 0;

   
       	printf("enter the number of minutes: \n");
	scanf("%d", &user);

   
       	while (min < user) {
       
	       	printf("%02d : %02d\n", min, sec);
        
       
	       	sleep(1);

       
	       	sec++;
       
	       	if (sec == 60) {
           
		       	sec = 0;
           
		       	min++;
       
	       	}
   
       	}

   
       	return 0;

}
