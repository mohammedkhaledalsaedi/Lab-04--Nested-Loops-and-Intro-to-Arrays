#include <stdio.h> 

int main() {


	int avg = 0;
	int sum = 0;
	//int city = 0;
	//int population = 0;
	int max;
	int min;
	int i = 0;

	int array[10];

	

	printf("enter the population of 10 cities:\n ");


	for (i = 1; i<=10; i++) { //storing
		
		printf("enter the population of city %d\n", i);
		scanf("%d", &array[i-1]);
	}


	printf("The population in reverse: \n");

	for (int j = 9; j>=0; j--) {


		printf("%d\n", array[j]);
	}


	min = array[0];
	max = array[0];
	for (i = 0; i<10; i++) {

		
		if (array[i] > max) {

			max = array[i];
		}
		

		
		if (array[i] < min) {

			min = array[i];
		}
		
	}
	printf("The maximum is: %d\n", max);
	printf("The minimum is: %d\n", min);


	for (i = 0; i<10; i++) {

		sum = sum + array[i];
		avg = sum/10;

	}

	printf("The Average population is: %d\n", avg);

	return 0;

}
