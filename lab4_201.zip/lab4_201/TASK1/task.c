#include <stdio.h>

int main() {
    int N = 0;

    printf("Enter the number of rows: ");
    scanf("%d", &N);

    // Using for loops
    for (int i = 1; i <= N; i++) {
        for (int j = 1; j <= N - i; j++) {
            printf(" ");
        }

        for (int j = 1; j <= i; j++) {
            printf("*");
        }

        printf("\n");
    }
    printf("\n");

    // Using while loops
    int i = 1;
    while (i <= N) {
        int j = 1;
        while (j <= N - i) {
            printf(" ");
            j++;
        }

        j = 1;
        while (j <= i) {
            printf("*");
            j++;
        }

        printf("\n");
        i++;
    }
    printf("\n");

    return 0;
}

